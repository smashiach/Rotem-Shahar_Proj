from get_relevant_points import eye_dimension_extract
from get_face_aligned import align_face
import glob
from sklearn import preprocessing
import numpy as np

right_eye_horizontal_distance = []
left_eye_horizontal_distance = []
distance_between_eyes = []
photo_path_array = []
ratio_array = []  # save the ratio according to
ratio_1 = []
ratio_2 = []
ratio_3 = []
ratio_4 = []
weighted_1 = 0.25
weighted_2 = 0.25
weighted_3 = 0.25
weighted_4 = 0.25

for img in glob.glob('D:\\Shahar\\Project A\\color_average\\training_set\\*.jpg'):  # The location of training set
    face_aligned = align_face(img)  # Aligned and extract face
    ratio_mouth_chin_nose, ratio_left_eye_nose, ratio_right_eye_nose, ratio_nose_width_middle_eyes, ratio_cheek_nose = eye_dimension_extract(face_aligned)
    if ratio_mouth_chin_nose == 0 or ratio_left_eye_nose == 0 or ratio_right_eye_nose == 0 or ratio_nose_width_middle_eyes == 0 or ratio_cheek_nose == 0:
        continue
    # photo_path_array.append(img)  # Get the picture name
    ratio_eyes_nose = (ratio_left_eye_nose + ratio_right_eye_nose)/2
    ratio_1.append(ratio_mouth_chin_nose)
    ratio_2.append(ratio_eyes_nose)
    ratio_3.append(ratio_nose_width_middle_eyes)
    ratio_4.append(ratio_cheek_nose)
    # weighted_score = ratio_mouth_chin_nose + ratio_eyes_nose + ratio_nose_width_middle_eyes + ratio_cheek_nose
    ratio_array.append([img])

# std_1 = np.std(ratio_1)
# std_2 = np.std(ratio_2)
# std_3 = np.std(ratio_3)
# std_4 = np.std(ratio_4)

norm_ratio_1 = preprocessing.normalize([ratio_1])
norm_ratio_2 = preprocessing.normalize([ratio_2])
norm_ratio_3 = preprocessing.normalize([ratio_3])
norm_ratio_4 = preprocessing.normalize([ratio_4])

norm_ratio_1 = norm_ratio_1 * weighted_1
norm_ratio_2 = norm_ratio_2 * weighted_2
norm_ratio_3 = norm_ratio_3 * weighted_3
norm_ratio_4 = norm_ratio_4 * weighted_4

final_score = []

for i in range(0, ratio_array.__len__()):
    tmp_score = norm_ratio_1[0][i] + norm_ratio_2[0][i] + norm_ratio_3[0][i] + norm_ratio_4[0][i]
    final_score.append([tmp_score, ratio_array[i]])


a = 1

b = np.histogram(final_score)